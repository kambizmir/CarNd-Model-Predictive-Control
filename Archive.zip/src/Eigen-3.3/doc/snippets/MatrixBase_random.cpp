cout << 100 * Matrix2i::Random() << endl;
